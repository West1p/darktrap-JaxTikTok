# DarkTrap — изменения относительно Froststrap

Основано на Froststrap (MPL-2.0). Лицензии и авторские заметки сохранены (LICENSE, LICENSES/, REUSE.toml).

1. Halloween-тема: Froststrap/App.axaml (оранжевый #FF7518 / фиолетовый / почти чёрный фон).
2. Имя: App.ProjectName = "DarkTrap", AssemblyName = DarkTrap, строки интерфейса во всех Strings*.resx.
3. Обновление Roblox: уже встроено в загрузчик — при каждом запуске сравнивается версия клиента
   с актуальной и при отличии докачивается новая. Не включайте "Player version override" в настройках.
4. Самообновление DarkTrap: UpdaterManager.UpdateRepository пустой => отключено
   (иначе приложение обновилось бы обратно до Froststrap). Укажите свой репозиторий с Velopack-релизами.

Сборка (Windows, .NET 10 SDK, из папки Froststrap):
    dotnet publish -c Release -r win-x64 -p:PublishAot=false
