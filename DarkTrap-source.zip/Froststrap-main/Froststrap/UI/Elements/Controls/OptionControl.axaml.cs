﻿// SPDX-FileCopyrightText: 2026 Froststrap
//
// SPDX-License-Identifier: MPL-2.0

using Avalonia;
using Avalonia.Controls.Primitives;
using Avalonia.Metadata;

namespace Froststrap.UI.Elements.Controls
{
    internal partial class OptionControl : TemplatedControl
    {
        public static readonly StyledProperty<string?> HeaderProperty =
            AvaloniaProperty.Register<OptionControl, string?>(nameof(Header));

        public static readonly StyledProperty<string?> DescriptionProperty =
            AvaloniaProperty.Register<OptionControl, string?>(nameof(Description));

        public static readonly StyledProperty<string?> HelpLinkProperty =
            AvaloniaProperty.Register<OptionControl, string?>(nameof(HelpLink));

        public static readonly StyledProperty<object?> InnerContentProperty =
            AvaloniaProperty.Register<OptionControl, object?>(nameof(InnerContent));

        public string? Header
        {
            get => GetValue(HeaderProperty);
            set => SetValue(HeaderProperty, value);
        }

        public string? Description
        {
            get => GetValue(DescriptionProperty);
            set => SetValue(DescriptionProperty, value);
        }

        public string? HelpLink
        {
            get => GetValue(HelpLinkProperty);
            set => SetValue(HelpLinkProperty, value);
        }

        [Content]
        public object? InnerContent
        {
            get => GetValue(InnerContentProperty);
            set => SetValue(InnerContentProperty, value);
        }
    }
}