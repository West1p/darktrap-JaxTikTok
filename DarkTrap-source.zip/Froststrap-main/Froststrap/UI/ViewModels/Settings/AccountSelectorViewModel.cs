// SPDX-FileCopyrightText: 2026 Froststrap
//
// SPDX-License-Identifier: MPL-2.0

using Avalonia.Controls;
using Avalonia.Media;
using Avalonia.Threading;
using CommunityToolkit.Mvvm.Input;
using Froststrap.Integrations;
using Froststrap.Integrations.AccountManager;
using Froststrap.UI.Elements.Dialogs;
using System.Collections.ObjectModel;

namespace Froststrap.UI.ViewModels.Settings
{
    internal partial class AccountSelectorViewModel : NotifyPropertyChangedViewModel, IDisposable
    {
        private readonly AccountManager _accountManager = null!;
        private readonly Dictionary<long, string?> _accountAvatarUrls = [];

        public event Action? OnManualAddRequested;

        private DispatcherTimer? _presenceTimer;
        private UserPresence? _currentPresence;
        private const int PRESENCE_REFRESH_INTERVAL_MS = 20000;

        private AccountManagerAccount? _currentAccount;
        public AccountManagerAccount? CurrentAccount
        {
            get => _currentAccount;
            set => SetProperty(ref _currentAccount, value);
        }

        private string? _currentAccountAvatarUrl;
        public string? CurrentAccountAvatarUrl
        {
            get => _currentAccountAvatarUrl;
            set => SetProperty(ref _currentAccountAvatarUrl, value);
        }

        private ObservableCollection<AccountWithAvatar> _accounts = [];
        public ObservableCollection<AccountWithAvatar> Accounts
        {
            get => _accounts;
            set => SetProperty(ref _accounts, value);
        }

        private string _selectedAddMethod = Strings.Menu_AccountSelector_Login_LocalCookie;
        public string SelectedAddMethod
        {
            get => _selectedAddMethod;
            set => SetProperty(ref _selectedAddMethod, value);
        }

        private bool _isDropdownOpen;
        public bool IsDropdownOpen
        {
            get => _isDropdownOpen;
            set
            {
                if (SetProperty(ref _isDropdownOpen, value) && value)
                {
                    _ = RefreshAllPresencesAsync();
                }
            }
        }

        private bool _isAddingAccount;
        public bool IsAddingAccount
        {
            get => _isAddingAccount;
            set => SetProperty(ref _isAddingAccount, value);
        }

        private UserPresence? CurrentPresence
        {
            get => _currentPresence;
            set
            {
                if (SetProperty(ref _currentPresence, value))
                {
                    OnPropertyChanged(nameof(PresenceTooltip));
                    UpdatePresenceBrush();
                }
            }
        }

        private IBrush _presenceBrush = Brushes.Gray;
        public IBrush PresenceBrush
        {
            get => _presenceBrush;
            private set => SetProperty(ref _presenceBrush, value);
        }

        private void UpdatePresenceBrush()
        {
            if (CurrentPresence == null)
            {
                PresenceBrush = Brushes.Gray;
                return;
            }

            int type = CurrentPresence.UserPresenceType;
            PresenceBrush = type switch
            {
                0 => Brushes.Gray,
                1 => Brushes.DodgerBlue,
                2 => Brushes.LimeGreen,
                3 => Brushes.Orange,
                _ => Brushes.Gray
            };
        }

        public string PresenceTooltip
        {
            get
            {
                if (CurrentPresence == null) return "Offline";
                return CurrentPresence.UserPresenceType switch
                {
                    0 => Strings.Menu_AccountSelector_Presence_Offline,
                    1 => Strings.Menu_AccountSelector_Presence_Online,
                    2 => Strings.Menu_AccountSelector_Presence_InGame,
                    3 => Strings.Menu_AccountSelector_Presence_InStudio,
                    _ => Strings.Common_Unknown
                };
            }
        }

        public List<string> AddMethods { get; } = [Strings.Menu_AccountSelector_Login_LocalCookie, Strings.Menu_Dialog_QuickSignIn_Title, Strings.Common_Manual, Strings.Common_Browser];

        public string CurrentAccountDisplayName => CurrentAccount == null ? Strings.Menu_AccountSelector_NotLoggedIn : $"@{CurrentAccount.Username}";

        public AccountSelectorViewModel()
        {
            if (Design.IsDesignMode)
                return;

            _accountManager = AccountManager.Shared;
            _accountManager.ActiveAccountChanged += OnActiveAccountChanged;

            Task.Run(async () =>
            {
                try
                {
                    await InitializeDataAsync();
                }
                catch (Exception ex)
                {
                    App.Logger.Error($"Safe catch: {ex.Message}");
                }
            });
        }

        private async Task InitializeDataAsync()
        {
            try
            {
                await LoadDataAsync();
                await ValidateAndRemoveInvalidAccountsAsync();
                App.Logger.Info("Initialised");
            }
            catch (Exception ex)
            {
                App.Logger.Error($"Exception: {ex.Message}");
            }
        }

        private async Task ValidateAndRemoveInvalidAccountsAsync()
        {
            var invalidAccounts = new List<AccountManagerAccount>();

            foreach (var account in _accountManager.Accounts)
            {
                bool? isValid = await AccountManager.ValidateAccountAsync(account);
                if (isValid == false)
                    invalidAccounts.Add(account);
                else if (isValid == null)
                    App.Logger.Warn($"Could not validate account {account.Username} (network/server issue) – keeping it.");
            }

            foreach (var account in invalidAccounts)
            {
                _accountManager.RemoveAccount(account);
                App.Logger.Info($"Removed expired/invalid account: {account.Username}");

                await Dispatcher.UIThread.InvokeAsync(() =>
                    Frontend.ShowMessageBox(string.Format(CultureInfo.InvariantCulture, Strings.Menu_AccountSelector_AccountRemoved, account.Username)));
            }

            if (invalidAccounts.Count > 0)
            {
                await LoadDataAsync();
            }
        }

        private async Task LoadDataAsync()
        {
            try
            {
                var mgr = _accountManager;
                var accountIds = mgr.Accounts.Select(acc => acc.UserId).ToList();

                if (accountIds.Count > 0)
                {
                    var avatarUrls = await mgr.GetAvatarUrlsBulkAsync(accountIds);
                    foreach (var kvp in avatarUrls)
                    {
                        _accountAvatarUrls[kvp.Key] = kvp.Value;
                    }
                }

                CurrentAccount = mgr.ActiveAccount;
                if (CurrentAccount != null)
                {
                    CurrentAccountAvatarUrl = GetAccountAvatarUrl(CurrentAccount.UserId);
                }
                OnPropertyChanged(nameof(CurrentAccountDisplayName));

                Accounts.Clear();
                foreach (var account in mgr.Accounts)
                {
                    var url = _accountAvatarUrls.TryGetValue(account.UserId, out var u) ? u : null;
                    Accounts.Add(new AccountWithAvatar(account, url));
                }

                await RefreshAllPresencesAsync();
            }
            catch (Exception ex)
            {
                App.Logger.Error($"Failed to load account data: {ex.Message}");
            }
        }

        private void OnActiveAccountChanged(AccountManagerAccount? account)
        {
            Dispatcher.UIThread.Post(() =>
            {
                CurrentAccount = account;
                CurrentAccountAvatarUrl = account != null ? GetAccountAvatarUrl(account.UserId) : null;
                OnPropertyChanged(nameof(CurrentAccountDisplayName));

                StopPresencePolling();
                if (account != null)
                {
                    StartPresencePolling();
                    _ = RefreshPresenceAsync();
                }
                else
                {
                    CurrentPresence = null;
                }
            });
        }

        private void StartPresencePolling()
        {
            if (_presenceTimer != null) return;

            _presenceTimer = new DispatcherTimer
            {
                Interval = TimeSpan.FromMilliseconds(PRESENCE_REFRESH_INTERVAL_MS)
            };
            _presenceTimer.Tick += async (s, e) => await RefreshPresenceAsync();
            _presenceTimer.Start();
        }

        private void StopPresencePolling()
        {
            _presenceTimer?.Stop();
            _presenceTimer = null;
        }

        private async Task RefreshPresenceAsync()
        {
            if (CurrentAccount == null) return;

            try
            {
                var presence = await AccountManager.GetUserPresenceAsync(CurrentAccount.UserId);
                if (presence != null)
                {
                    CurrentPresence = presence;
                }
            }
            catch (Exception ex)
            {
                App.Logger.Error($"Failed to refresh presence: {ex.Message}");
            }
        }

        private async Task RefreshAllPresencesAsync()
        {
            var tasks = Accounts.Select(async item =>
            {
                try
                {
                    var presence = await AccountManager.GetUserPresenceAsync(item.UserId);
                    await Dispatcher.UIThread.InvokeAsync(() =>
                    {
                        item.PresenceStatus = presence?.UserPresenceType switch
                        {
                            0 => "Offline",
                            1 => "Online",
                            2 => "In Game",
                            3 => "In Studio",
                            _ => "Unknown"
                        };
                        item.PresenceBrush = presence?.UserPresenceType switch
                        {
                            0 => Brushes.Gray,
                            1 => Brushes.DodgerBlue,
                            2 => Brushes.LimeGreen,
                            3 => Brushes.Orange,
                            _ => Brushes.Gray
                        };
                    });
                }
                catch (Exception ex)
                {
                    App.Logger.Error($"Failed to fetch presence for user {item.UserId}: {ex.Message}");
                }
            });
            await Task.WhenAll(tasks);
        }

        public void MoveAccount(int fromIndex, int toIndex, bool persist = true)
        {
            if (fromIndex < 0 || fromIndex >= Accounts.Count) return;
            if (toIndex < 0 || toIndex >= Accounts.Count) return;
            if (fromIndex == toIndex) return;

            Accounts.Move(fromIndex, toIndex);

            if (persist)
                SaveAccountOrder();
        }

        public void SaveAccountOrder()
        {
            _accountManager.ReorderAccounts([.. Accounts.Select(a => a.Account)]);
        }

        [RelayCommand]
        private void SelectAccount(AccountWithAvatar item)
        {
            _accountManager.SetActiveAccount(item.UserId);
            IsDropdownOpen = false;
        }

        [RelayCommand]
        private void ToggleDropdown() => IsDropdownOpen = !IsDropdownOpen;

        [RelayCommand]
        private void DeleteAccount(AccountWithAvatar item)
        {
            _accountManager.RemoveAccount(item.Account);
            Accounts.Remove(item);
        }

        [RelayCommand]
        private async Task AddAccount()
        {
            IsAddingAccount = true;

            try
            {
                AccountManagerAccount? newAccount = null;

                if (SelectedAddMethod == Strings.Menu_Dialog_QuickSignIn_Title)
                {
                    var dialog = new QuickSignCodeDialog();
                    var cts = new CancellationTokenSource();

                    void OnDialogClosed(object? _, EventArgs __)
                    {
                        dialog.Closed -= OnDialogClosed;
                        try { cts.Cancel(); }
                        catch (ObjectDisposedException) { }
                    }

                    dialog.Closed += OnDialogClosed;
                    dialog.Show();

                    try
                    {
                        newAccount = await AccountManager.AddAccountByQuickSignInAsync(dialog, cts.Token);
                    }
                    finally
                    {
                        dialog.Closed -= OnDialogClosed;
                        cts.Dispose();
                    }
                }
                else if (SelectedAddMethod == Strings.Common_Browser)
                {
                    newAccount = await AccountManager.AddAccountByBrowserAsync();
                }
                else if (SelectedAddMethod == Strings.Common_Manual)
                {
                    OnManualAddRequested?.Invoke();
                    return;
                }
                else if (SelectedAddMethod == Strings.Menu_AccountSelector_Login_LocalCookie)
                {
                    newAccount = await ImportFromCookieManager();
                }

                if (newAccount == null) return;

                if (await HandleDuplicateAccountAsync(newAccount))
                    return;

                _accountManager.AddAccount(newAccount);

                var avatarUrlMap = await _accountManager.GetAvatarUrlsBulkAsync([newAccount.UserId]);
                var url = avatarUrlMap.GetValueOrDefault(newAccount.UserId);
                _accountAvatarUrls[newAccount.UserId] = url;

                Accounts.Add(new AccountWithAvatar(newAccount, url));
                _accountManager.SetActiveAccount(newAccount.UserId);
                IsDropdownOpen = false;
            }
            catch (Exception ex)
            {
                App.Logger.Error($"Error adding account: {ex.Message}");
            }
            finally
            {
                IsAddingAccount = false;
            }
        }

        private async Task<bool> HandleDuplicateAccountAsync(AccountManagerAccount account)
        {
            var existing = _accountManager.Accounts.FirstOrDefault(a => a.UserId == account.UserId);
            if (existing == null)
                return false;

            var updated = _accountManager.AddOrUpdateAccount(account, out _);
            ReplaceAccountEntry(updated);

            _accountManager.SetActiveAccount(updated.UserId);
            IsDropdownOpen = false;

            await Frontend.ShowMessageBox(
                string.Format(CultureInfo.InvariantCulture, Strings.Menu_AccountSelector_AlreadyLoggedIn, updated.Username),
                MessageBoxImage.Information);

            return true;
        }

        private void ReplaceAccountEntry(AccountManagerAccount updated)
        {
            int index = -1;
            for (int i = 0; i < Accounts.Count; i++)
            {
                if (Accounts[i].UserId == updated.UserId)
                {
                    index = i;
                    break;
                }
            }

            if (index < 0)
                return;

            var old = Accounts[index];
            _accountAvatarUrls.TryGetValue(updated.UserId, out var url);

            Accounts[index] = new AccountWithAvatar(updated, url ?? old.AvatarUrl)
            {
                PresenceStatus = old.PresenceStatus,
                PresenceBrush = old.PresenceBrush
            };
        }

        private static async Task<AccountManagerAccount?> ImportFromCookieManager()
        {
            var cookieManager = new CookiesManager();

            await cookieManager.LoadCookies();

            if (!cookieManager.Loaded)
            {
                string error = cookieManager.State switch
                {
                    CookieState.NotAllowed => Strings.Menu_CookieState_NotAllowed,
                    CookieState.NotFound => Strings.Menu_CookieState_NotFound,
                    CookieState.Invalid => Strings.Menu_CookieState_Invalid,
                    CookieState.Failed => Strings.Menu_CookieState_Failed,
                    _ => Strings.Menu_CookieState_CouldNotLoad
                };
                _ = Frontend.ShowMessageBox(error);
                return null;
            }

            var authUser = await cookieManager.GetAuthenticated();
            if (authUser == null || authUser.Id == 0)
            {
                App.Logger.Error("Failed to get authenticated user from cookie.");
                return null;
            }

            string cookieValue = cookieManager.GetAuthCookie();
            if (string.IsNullOrEmpty(cookieValue))
            {
                App.Logger.Warn("Auth cookie is empty.");
                return null;
            }

            return new AccountManagerAccount(
                securityToken: cookieValue,
                userId: authUser.Id,
                username: authUser.Username,
                displayName: authUser.DisplayName
            );
        }

        public async void AddAccountDirect(AccountManagerAccount account)
        {
            if (await HandleDuplicateAccountAsync(account))
                return;

            _accountManager.AddAccount(account);

            string? avatarUrl = null;
            try
            {
                var urlMap = await _accountManager.GetAvatarUrlsBulkAsync([account.UserId]);
                avatarUrl = urlMap.GetValueOrDefault(account.UserId);
                if (avatarUrl != null)
                    _accountAvatarUrls[account.UserId] = avatarUrl;
            }
            catch (Exception ex)
            {
                App.Logger.Error($"Failed to fetch avatar for {account.UserId}: {ex.Message}");
            }

            if (Accounts.All(a => a.UserId != account.UserId))
            {
                Accounts.Add(new AccountWithAvatar(account, avatarUrl));
            }

            _accountManager.SetActiveAccount(account.UserId);
            IsDropdownOpen = false;
        }

        [RelayCommand]
        private static void ApplyAccount(AccountWithAvatar item)
        {
            if (item == null) return;

            bool success = AccountManager.WriteCookieFileForAccount(item.Account);
            if (success)
            {
                _ = Frontend.ShowMessageBox(string.Format(CultureInfo.InvariantCulture, Strings.AccountManager_Replace_Success, item.Username));
            }
            else
            {
                _ = Frontend.ShowMessageBox(string.Format(CultureInfo.InvariantCulture, Strings.AccountManager_Replace_Failed, item.Username), MessageBoxImage.Error);
            }
        }

        internal class AccountWithAvatar : NotifyPropertyChangedViewModel
        {
            public AccountManagerAccount Account { get; }
            public string? AvatarUrl { get; }

            public string Username => Account.Username;
            public string DisplayName => Account.DisplayName;
            public long UserId => Account.UserId;

            private string _presenceStatus = "Unknown";
            public string PresenceStatus
            {
                get => _presenceStatus;
                set => SetProperty(ref _presenceStatus, value);
            }

            private IBrush _presenceBrush = Brushes.Gray;
            public IBrush PresenceBrush
            {
                get => _presenceBrush;
                set => SetProperty(ref _presenceBrush, value);
            }

            public AccountWithAvatar(AccountManagerAccount account, string? avatarUrl)
            {
                Account = account;
                AvatarUrl = avatarUrl;
            }
        }

        public string? GetAccountAvatarUrl(long userId)
        {
            return _accountAvatarUrls.TryGetValue(userId, out var url)
                ? url
                : _accountManager.GetCachedAvatarUrl(userId);
        }

        public void Dispose()
        {
            StopPresencePolling();
            _accountManager.ActiveAccountChanged -= OnActiveAccountChanged;
            GC.SuppressFinalize(this);
        }
    }
}
