﻿// SPDX-FileCopyrightText: 2026 Froststrap
//
// SPDX-License-Identifier: MPL-2.0

using Froststrap.Enums.AppStoragePresets;
using System.Collections.ObjectModel;

namespace Froststrap.Models.Persistable
{
    internal class Settings
    {

        // Integration Page
        public bool EnableActivityTracking { get; set; } = true;
        public bool ShowServerDetails { get; set; } = true;
        public bool ShowServerUptime { get; set; } = true;
        public bool AutoRejoin { get; set; }
        public bool ShowGameHistoryMenu { get; set; } = true;
        public bool PlaytimeCounter { get; set; } = true;
        public TrayDoubleClickAction DoubleClickAction { get; set; } = TrayDoubleClickAction.ServerInfo;
        public bool UseDisableAppPatch { get; set; }
        public bool AutoChangeTitle { get; set; } = true;
        public bool AutoChangeTitleWithPlayerCount { get; set; } = true;
        public bool AutoChangeIcon { get; set; }
        public bool ShowUsingFroststrapRPC { get; set; } = true;
        public bool UseDiscordRichPresence { get; set; } = true;
        public bool HideRPCButtons { get; set; } = true;
        public bool EnableCustomStatusDisplay { get; set; } = true;
        public bool ShowAccountOnRichPresence { get; set; }
        public bool StudioRPC { get; set; }
        public bool StudioThumbnailChanging { get; set; }
        public bool StudioEditingInfo { get; set; }
        public bool StudioWorkspaceInfo { get; set; }
        public bool StudioShowTesting { get; set; }
        public bool StudioGameButton { get; set; }
        public ObservableCollection<CustomIntegration> CustomIntegrations { get; set; } = [];

        // Bootstrapper Page
        public bool ConfirmLaunches { get; set; } = true;
        public bool AllowCookieAccess { get; set; }
        public bool AutoCloseCrashHandler { get; set; }
        public CleanerOptions CleanerOptions { get; set; } = CleanerOptions.Never;
        public List<string> CleanerDirectories { get; set; } = [];
        public bool BackgroundUpdatesEnabled { get; set; }
        public bool LaunchWithVirtualDisplay { get; set; }
        public string VirtualDisplayName { get; set; } = "";
        public int VirtualDisplayWidth { get; set; }
        public int VirtualDisplayHeight { get; set; }
        public double[] VirtualDisplayHzModes { get; set; } = [ 24.0, 25.0, 30.0, 60.0, 120.0, 144.0, 240.0 ];
        public uint VirtualDisplaySerial { get; set; }
        public bool SoftKeyEnabled { get; set; }
        public SoftKeyProfile SoftKeyProfile { get; set; } = SoftKeyProfile.WASD;
        public bool EnableBetterMatchmaking { get; set; }
        public string SelectedRegion { get; set; } = Strings.Common_Auto;
        public bool EnableRobloxBackgroundApp { get; set; }
        public RobloxTheme RobloxTheme { get; set; } = RobloxTheme.Default;

        // FastFlag Editor/Settings
        public bool UseFastFlagManager { get; set; } = true;
        public Dictionary<string, List<string>> ProfilePlaceIds { get; set; } = [];

        // Appearance Page
        public bool BootstrapperShowInfo { get; set; }
        public BootstrapperStyle BootstrapperStyle { get; set; } = BootstrapperStyle.FluentAeroDialog;
        public string? SelectedCustomTheme { get; set; }
        public bool CycleEnabled { get; set; }
        public CycleFrequency CycleFrequency { get; set; } = CycleFrequency.EveryLaunch;
        public int CycleIntervalValue { get; set; } = 1;
        public List<string> CycleEnabledCustomThemes { get; set; } = [];
        public int CycleCurrentIndex { get; set; }
        public DateTime CycleLastCycleTime { get; set; } = DateTime.MinValue;
        public BootstrapperIcon BootstrapperIcon { get; set; } = BootstrapperIcon.IconFroststrap;
        public WindowsBackdrops SelectedBackdrop { get; set; } = WindowsBackdrops.None;
        public string Locale { get; set; } = "nil";
        public List<GradientStops> CustomGradientStops { get; set; } =
        [
            new GradientStops { Offset = 0.0, Color = "#8025304A" },
            new GradientStops { Offset = 0.5, Color = "#80272F48" },
            new GradientStops { Offset = 1.0, Color = "#80202C36" }
        ];
        public double? GradientAngle { get; set; } = 45;
        public BackgroundMode BackgroundType { get; set; } = BackgroundMode.Gradient;
        public string? BackgroundImagePath { get; set; } = "";
        public BackgroundStretch BackgroundStretch { get; set; } = BackgroundStretch.Fill;
        public double BackgroundOpacity { get; set; } = 1.0;
        public string BootstrapperTitle { get; set; } = App.ProjectName;
        public string BootstrapperIconCustomLocation { get; set; } = "";
        public Theme Theme { get; set; } = Theme.Default;
        public bool EnableWindowManipulation { get; set; }
        public RobloxIcon RobloxIcon { get; set; } = RobloxIcon.IconDefault;
        public string RobloxTitle { get; set; } = "Roblox";
        public string RobloxIconCustomLocation { get; set; } = "";

        // Deployment Page
        public UpdateCheck UpdateChecks { get; set; } = UpdateCheck.Stable;
        public bool DisableAnimations { get; set; }
        public bool UpdateRoblox { get; set; } = true;
        public bool AutomaticallyUpdateSober { get; set; } = true;
        public int MaxThreadDownload { get; set; } = 3;
        public string RobloxDomain { get; set; } = RobloxInterfaces.Deployment.DefaultRobloxDomain;
        public bool StaticDirectory { get; set; }
        public string PlayerChannel { get; set; } = RobloxInterfaces.Deployment.DefaultChannel;
        public string StudioChannel { get; set; } = RobloxInterfaces.Deployment.DefaultChannel;
        public ChannelChangeMode ChannelChangeMode { get; set; } = ChannelChangeMode.Prompt;
        public bool StudioVersionOverrideEnabled { get; set; }
        public string StudioVersionOverrideHash { get; set; } = string.Empty;
        public bool PlayerVersionOverrideEnabled { get; set; }
        public string PlayerVersionOverrideHash { get; set; } = string.Empty;

        // Linux Settings page
        public bool EnableWebView2 { get; set; } = true;
        public string? StudioVirtualDesktop { get; set; } = string.Empty;
        public string? StudioLauncher { get; set; } = string.Empty;
        public StudioRenderer StudioRenderer { get; set; } = StudioRenderer.DXVK;
        public bool StudioGameMode { get; set; }
        public bool StudioDebug { get; set; }
        public Dictionary<string, string> StudioEnvironmentVariables { get; set; } = [];

        // Misc Stuff
        public bool ForceLocalData { get; set; }
        public bool DebugDisableVersionPackageCleanup { get; set; }
    }
}
