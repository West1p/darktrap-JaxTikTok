﻿// SPDX-FileCopyrightText: 2026 Froststrap
//
// SPDX-License-Identifier: MPL-2.0

using Avalonia.Media;
using Froststrap.UI.ViewModels;

namespace Froststrap.Models
{
    internal class GradientStops : NotifyPropertyChangedViewModel
    {
        private double _offset;
        public double Offset
        {
            get => _offset;
            set
            {
                _offset = value;
                OnPropertyChanged(nameof(Offset));
            }
        }

        private string _color = "#FFFFFF";

        public string Color
        {
            get => _color;
            set
            {
                var cleaned = string.IsNullOrWhiteSpace(value)
                    ? value
                    : string.Concat(value.Where(c => !char.IsWhiteSpace(c)));

                if (_color != cleaned)
                {
                    _color = cleaned;
                    OnPropertyChanged();
                }
            }
        }
    }
}