﻿// SPDX-FileCopyrightText: 2026 Froststrap
//
// SPDX-License-Identifier: MPL-2.0

using Froststrap.UI.ViewModels;
using LucideAvalonia.Enum;

namespace Froststrap.Models
{
    internal class FastFlag : NotifyPropertyChangedViewModel
    {
        private LucideIconNames _preset = LucideIconNames.CircleCheck;
        private string _name = string.Empty;
        private string _value = string.Empty;

        public LucideIconNames Preset
        {
            get => _preset;
            set => SetProperty(ref _preset, value);
        }

        public string Name
        {
            get => _name;
            set => SetProperty(ref _name, value);
        }

        public string Value
        {
            get => _value;
            set => SetProperty(ref _value, value);
        }
    }
}
