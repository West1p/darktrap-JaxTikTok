// SPDX-FileCopyrightText: 2026 Froststrap
//
// SPDX-License-Identifier: MPL-2.0

using NLog;
using Avalonia;
using Velopack;
using Froststrap;
using Froststrap.Backend;
using Froststrap.Cli;

namespace Froststrap;

sealed partial class Program
{
    private static readonly Logger Logger = LogManager.GetCurrentClassLogger();

    internal static readonly Stopwatch StartupTimer = Stopwatch.StartNew();

#if _WIN32
    private const int AttachParentProcess = -1;

    [System.Runtime.InteropServices.LibraryImport("kernel32.dll")]
    private static partial int AllocConsole();

    [System.Runtime.InteropServices.LibraryImport("kernel32.dll")]
    private static partial int AttachConsole(int dwProcessId);
#endif

    private static void AttachParentConsole()
    {
#if _WIN32
        _ = AttachConsole(AttachParentProcess);
#endif
    }

    [STAThread]
    public static int Main(string[] args)
    {
        AppInitializer.InitializeNativeResolvers();

        VelopackApp.Build()
            .SetAutoApplyOnStartup(false)
            .OnAfterInstallFastCallback(v => UriHandler.RegisterProtocolHandlers())
            .OnAfterUpdateFastCallback(v => UriHandler.RegisterProtocolHandlers())
            .OnBeforeUninstallFastCallback(v => UriHandler.UnregisterProtocolHandlers())
            .Run();

        // shim to convert old args to new ones
        string[] launchArgs = args.Length == 0 ? [] : LegacyArgs.Normalize(args);

#if _WIN32
        if (launchArgs.Any(static a => a is "--console" or "-c"))
            _ = AllocConsole();
#endif

        Logging.Configure(Paths.Logs);
        _ = Task.Run(() => AppInitializer.RunMacSecurityDiagnostics());
        NativeLog.Register();

        if (launchArgs.Length == 0)
        {
            App.LaunchSettings = new LaunchSettings(new FroststrapCliCommand(), launchArgs);
        }
        else
        {
            var parseResult = DotMake.CommandLine.Cli.Parse<FroststrapCliCommand>(launchArgs);

            if (LegacyArgs.RequestsHelpOrVersion(launchArgs))
            {
                AttachParentConsole();
                int exitCode = parseResult.ParseResult.Invoke();
                LogManager.Shutdown();
                return exitCode;
            }

            if (parseResult.ParseResult.Errors.Count > 0)
            {
                AttachParentConsole();

                foreach (var parseError in parseResult.ParseResult.Errors)
                {
                    Console.Error.WriteLine(parseError.Message);
                    Logger.Error(parseError.Message);
                }

                LogManager.Shutdown();
                return (int)ErrorCode.ERROR_CANCELLED;
            }

            var cli = parseResult.Bind<FroststrapCliCommand>();
            App.LaunchSettings = new LaunchSettings(cli, launchArgs);
        }

        var launchSettings = App.LaunchSettings;

        if (launchSettings.UnknownArgs.Count > 0)
        {
            var unknown = launchSettings.UnknownArgs;
            Logger.Error($"{unknown.Count} unrecognized argument(s): {string.Join(", ", unknown)}");
            LogManager.Shutdown();
            return (int)ErrorCode.ERROR_CANCELLED;
        }

        if (launchArgs.Length != 0)
            Logger.Debug($"Arguments: {string.Join(" ", launchArgs)}");

        Logger.Debug($"Log file: {Logging.FileLocation}");

        try
        {
#if __APPLE__
            NativeNotify.Init();
#endif
            BuildAvaloniaApp().StartWithClassicDesktopLifetime(args);
        }
        catch (Exception ex)
        {
            Logger.Fatal(ex, "Unhandled exception during startup");
            throw;
        }
        finally
        {
            LogManager.Shutdown();
        }

        return 0;
    }


    public static AppBuilder BuildAvaloniaApp()
    {
        var builder = AppBuilder.Configure<App>()
            .UsePlatformDetect()
#if DEBUG
            .WithDeveloperTools()
#endif
            .LogToTrace();

        if (OperatingSystem.IsWindows() && App.LaunchSettings?.NoGpuFlag.Active == true)
        {
            builder = builder.With(new Win32PlatformOptions
            {
                RenderingMode = [Win32RenderingMode.Software]
            });
        }

        if (OperatingSystem.IsLinux() &&
            !string.IsNullOrWhiteSpace(Environment.GetEnvironmentVariable("FROSTSTRAP_FORCE_WAYLAND")))
        {
            App.Logger.Debug("Using Wayland backend (FROSTSTRAP_FORCE_WAYLAND)");

            builder = builder.UseWayland()
                .With(new WaylandPlatformOptions
                {
                    UseDmabufSwapchain = true
                });
        }

        return builder;
    }
}
