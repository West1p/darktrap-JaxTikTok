﻿// SPDX-FileCopyrightText: 2026 Froststrap
// Copyright (C) Froststrap Team
//
// SPDX-License-Identifier: MPL-2.0

using System.Runtime.InteropServices;
using Avalonia.Media.Imaging;
using Avalonia.Platform;

namespace Froststrap.Utility
{
    internal static class Shortcut
    {
        private static GenericTriState _loadStatus = GenericTriState.Unknown;

        private static string? _froststrapIconPath;
        private static readonly Lock _iconLock = new();

        public static string GetFroststrapIconPath()
        {
            if (_froststrapIconPath != null && File.Exists(_froststrapIconPath))
                return _froststrapIconPath;

            lock (_iconLock)
            {
                if (_froststrapIconPath != null && File.Exists(_froststrapIconPath))
                    return _froststrapIconPath;

                try
                {
                    string iconPath = Path.Combine(Paths.Base, "froststrap.png");

                    if (File.Exists(iconPath))
                    {
                        _froststrapIconPath = iconPath;
                        return iconPath;
                    }

                    var uri = new Uri("avares://Froststrap/Froststrap.png");
                    using var pngStream = AssetLoader.Open(uri);
                    _ = pngStream ?? throw new FileNotFoundException("Embedded Froststrap.png not found.");

                    using var fileStream = File.Create(iconPath);
                    pngStream.CopyTo(fileStream);

                    _froststrapIconPath = iconPath;
                    return iconPath;
                }
                catch (Exception ex)
                {
                    App.Logger.Error($"Failed to extract icon: {ex.Message}");
                    return "application-x-executable";
                }
            }
        }

        public static string ResolvePath(string lnkPath)
        {
            if (OperatingSystem.IsLinux())
                return Path.ChangeExtension(lnkPath, ".desktop");
            if (OperatingSystem.IsMacOS() && !lnkPath.EndsWith(".app", StringComparison.Ordinal))
                return lnkPath + ".app";
            return lnkPath;
        }

        public static async void Create(string exePath, string exeArgs, string lnkPath, string? iconPath = null)
        {
            string resolvedPath = ResolvePath(lnkPath);

            if (File.Exists(resolvedPath))
                return;

            try
            {
                if (OperatingSystem.IsWindows())
                    CreateWindowsShortcut(exePath, exeArgs, lnkPath, iconPath);
                else if (OperatingSystem.IsMacOS())
                    CreateMacOsShortcut(exePath, exeArgs, lnkPath);
                else if (OperatingSystem.IsLinux())
                    CreateLinuxShortcut(exePath, exeArgs, lnkPath, iconPath);

                if (_loadStatus != GenericTriState.Successful)
                    _loadStatus = GenericTriState.Successful;
            }
            catch (Exception ex)
            {
                App.Logger.Error($"Failed to create a shortcut for {resolvedPath}! {ex}");

                if (_loadStatus == GenericTriState.Failed)
                    return;

                _loadStatus = GenericTriState.Failed;

                await Frontend.ShowMessageBox(Strings.Dialog_CannotCreateShortcuts, MessageBoxImage.Warning);
            }
        }

        public static void Delete(string lnkPath)
        {
            // Always try to clean up the raw path too in case an old .lnk was left behind.
            if (File.Exists(lnkPath))
                File.Delete(lnkPath);

            string resolvedPath = ResolvePath(lnkPath);
            if (File.Exists(resolvedPath))
                File.Delete(resolvedPath);

            if (OperatingSystem.IsLinux())
            {
                string appMenuPath = Path.Combine(
                    GetLinuxAppMenuDir(),
                    Path.GetFileName(resolvedPath)
                );
                if (File.Exists(appMenuPath))
                    File.Delete(appMenuPath);
            }
        }

        public static async Task CreateGameShortcut(
            string appPath,
            string placeId,
            string? jobId,
            string? accessCode,
            Bitmap? icon,
            Action<string>? onStatus = null)
        {
            string argData = placeId;
            if (!string.IsNullOrEmpty(jobId)) argData += $";{jobId}";
            if (!string.IsNullOrEmpty(accessCode)) argData += $";{accessCode}";

            string safeName = SanitizeFileName(placeId); // caller should pass display name; kept generic here
            string lnkPath = Path.Combine(Paths.Desktop, $"{safeName}.lnk");

            string? finalIconPath = null;

            if (icon != null)
            {
                try
                {
                    onStatus?.Invoke("Saving icon...");

                    string shortcutsIconDir = Path.Combine(Paths.Cache, "Game Shortcuts");
                    Directory.CreateDirectory(shortcutsIconDir);

                    using var ms = new MemoryStream();
                    icon.Save(ms, PngBitmapEncoderOptions.Default);
                    byte[] imageBytes = ms.ToArray();

                    string hash = ComputeHash(imageBytes);
                    string icoPath = Path.Combine(shortcutsIconDir, $"{hash}.ico");

                    if (!File.Exists(icoPath))
                    {
                        onStatus?.Invoke("Converting icon...");
                        using var icoFile = File.Create(icoPath);
                        SaveBitmapAsIcon(icon, icoFile);
                    }

                    finalIconPath = icoPath;
                }
                catch (Exception ex)
                {
                    App.Logger.Error($"Icon processing failed: {ex.Message}");
                }
            }

            onStatus?.Invoke("Creating...");
            Create(appPath, $"--game-shortcut \"{argData}\"", lnkPath, finalIconPath);
        }

        public static Task CreateGameShortcut(
            string appPath,
            string displayName,
            string placeId,
            string? jobId,
            string? accessCode,
            Bitmap? icon,
            Action<string>? onStatus = null)
        {
            string safeName = SanitizeFileName(displayName);
            string lnkPath = Path.Combine(Paths.Desktop, $"{safeName}.lnk");

            // Delegate with the resolved lnk path baked in via a local wrapper.
            return CreateGameShortcutInternal(appPath, placeId, jobId, accessCode, icon, lnkPath, onStatus);
        }

        private static async Task CreateGameShortcutInternal(
            string appPath,
            string placeId,
            string? jobId,
            string? accessCode,
            Bitmap? icon,
            string lnkPath,
            Action<string>? onStatus)
        {
            string deeplink = $"roblox://experiences/start?placeId={placeId}";
            if (!string.IsNullOrEmpty(accessCode))
                deeplink += $"&accessCode={accessCode}";
            else if (!string.IsNullOrEmpty(jobId))
                deeplink += $"&gameInstanceId={jobId}";

            string? finalIconPath = null;

            if (icon != null)
            {
                try
                {
                    onStatus?.Invoke("Saving icon...");

                    string shortcutsIconDir = Path.Combine(Paths.Cache, "Game Shortcuts");
                    Directory.CreateDirectory(shortcutsIconDir);

                    using var ms = new MemoryStream();
                    icon.Save(ms, PngBitmapEncoderOptions.Default);
                    byte[] imageBytes = ms.ToArray();

                    string hash = ComputeHash(imageBytes);
                    string icoPath = Path.Combine(shortcutsIconDir, $"{hash}.ico");

                    if (!File.Exists(icoPath))
                    {
                        onStatus?.Invoke("Converting icon...");
                        using var icoFile = File.Create(icoPath);
                        SaveBitmapAsIcon(icon, icoFile);
                    }

                    finalIconPath = icoPath;
                }
                catch (Exception ex)
                {
                    App.Logger.Error($"Icon processing failed: {ex.Message}");
                }
            }

            onStatus?.Invoke("Creating...");
            Create(appPath, $"-p \"{deeplink}\"", lnkPath, finalIconPath);
        }

        private static unsafe void CreateWindowsShortcut(
            string exePath,
            string exeArgs,
            string lnkPath,
            string? iconPath
        )
        {
            Guid clsid = new("00021401-0000-0000-C000-000000000046");
            Guid iid = new("000214F9-0000-0000-C000-000000000046");
            const uint CLSCTX_INPROC_SERVER = 0x1;

            int hr = CoCreateInstance(ref clsid, IntPtr.Zero, CLSCTX_INPROC_SERVER, ref iid, out IntPtr shellLink);
            Marshal.ThrowExceptionForHR(hr);

            IntPtr persistFile = IntPtr.Zero;

            try
            {
                Guid persistFileIid = new("0000010b-0000-0000-C000-000000000046");
                hr = QueryInterface(shellLink, ref persistFileIid, out persistFile);
                Marshal.ThrowExceptionForHR(hr);

                SetShellLinkString(shellLink, 20, exePath);
                SetShellLinkString(shellLink, 11, exeArgs);
                SetShellLinkString(shellLink, 9, Path.GetDirectoryName(exePath) ?? string.Empty);

                var finalIconPath = string.IsNullOrWhiteSpace(iconPath)
                    ? exePath
                    : iconPath;

                SetShellLinkIconLocation(shellLink, finalIconPath, 0);

                hr = SavePersistFile(persistFile, lnkPath);
                Marshal.ThrowExceptionForHR(hr);
            }
            finally
            {
                if (persistFile != IntPtr.Zero)
                    ReleaseComObject(persistFile);

                ReleaseComObject(shellLink);
            }
        }

        [DllImport("ole32.dll", ExactSpelling = true, PreserveSig = true)]
        private static extern int CoCreateInstance(
            ref Guid rclsid,
            IntPtr pUnkOuter,
            uint dwClsContext,
            ref Guid riid,
            out IntPtr ppv);

        private static unsafe int QueryInterface(IntPtr obj, ref Guid riid, out IntPtr ppv)
        {
            Guid iid = riid;
            IntPtr result = IntPtr.Zero;
            int hr;

            Guid* iidPtr = &iid;
            var fn = (delegate* unmanaged[Stdcall]<IntPtr, Guid*, IntPtr*, int>)(*(IntPtr**)obj)[0];
            hr = fn(obj, iidPtr, &result);

            ppv = result;
            return hr;
        }

        private static unsafe int SetShellLinkString(IntPtr obj, int slot, string value)
        {
            var fn = (delegate* unmanaged[Stdcall]<IntPtr, char*, int>)(*(IntPtr**)obj)[slot];

            fixed (char* valuePtr = value)
                return fn(obj, valuePtr);
        }

        private static unsafe int SetShellLinkIconLocation(IntPtr obj, string path, int index)
        {
            var fn = (delegate* unmanaged[Stdcall]<IntPtr, char*, int, int>)(*(IntPtr**)obj)[17];

            fixed (char* pathPtr = path)
                return fn(obj, pathPtr, index);
        }

        private static unsafe int SavePersistFile(IntPtr obj, string path)
        {
            var fn = (delegate* unmanaged[Stdcall]<IntPtr, char*, int, int>)(*(IntPtr**)obj)[6];

            fixed (char* pathPtr = path)
                return fn(obj, pathPtr, 1);
        }

        private static unsafe void ReleaseComObject(IntPtr obj)
        {
            var fn = (delegate* unmanaged[Stdcall]<IntPtr, uint>)(*(IntPtr**)obj)[2];
            fn(obj);
        }

        // idk if these will work at all
        private static void CreateMacOsShortcut(string exePath, string exeArgs, string appBundlePath)
        {
            if (!appBundlePath.EndsWith(".app", StringComparison.OrdinalIgnoreCase))
                appBundlePath += ".app";

            string contentsDir = Path.Combine(appBundlePath, "Contents");
            string macOsDir = Path.Combine(contentsDir, "MacOS");

            Directory.CreateDirectory(macOsDir);

            string scriptPath = Path.Combine(macOsDir, "launcher");
            File.WriteAllText(scriptPath,
                $"""
                #!/bin/bash
                exec "{exePath}" {exeArgs}
                """);

            Process.Start("chmod", $"+x \"{scriptPath}\"")?.WaitForExit();

            File.WriteAllText(Path.Combine(contentsDir, "Info.plist"),
                $"""
                <?xml version="1.0" encoding="UTF-8"?>
                <!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
                    "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
                <plist version="1.0">
                <dict>
                    <key>CFBundleExecutable</key>  <string>launcher</string>
                    <key>CFBundleIdentifier</key>  <string>com.froststrap.shortcut</string>
                    <key>CFBundleName</key>         <string>{Path.GetFileNameWithoutExtension(appBundlePath)}</string>
                    <key>CFBundleVersion</key>      <string>1.0</string>
                </dict>
                </plist>
                """);
        }

        private static void CreateLinuxShortcut(string exePath, string exeArgs, string desktopPath, string? iconPath)
        {
            string finalDesktopPath = Path.ChangeExtension(desktopPath, ".desktop");
            string appName = Path.GetFileNameWithoutExtension(finalDesktopPath);
            string icon = string.IsNullOrEmpty(iconPath) ? GetFroststrapIconPath() : iconPath;

            string content =
                $"""
                [Desktop Entry]
                Type=Application
                Name={appName}
                Exec="{exePath}" {exeArgs}
                Icon={icon}
                Terminal=false
                """;

            File.WriteAllText(finalDesktopPath, content);
            Process.Start("chmod", $"+x \"{finalDesktopPath}\"")?.WaitForExit();

            // also put in a directory that app launchers index
            string appsDir = GetLinuxAppMenuDir();
            Directory.CreateDirectory(appsDir);
            string appMenuPath = Path.Combine(appsDir, Path.GetFileName(finalDesktopPath));
            File.WriteAllText(appMenuPath, content);
        }

        private static string GetLinuxAppMenuDir() =>
            Path.Combine(Paths.UserProfile, ".local", "share", "applications");

        private static void SaveBitmapAsIcon(Bitmap bitmap, Stream output)
        {
            using var ms = new MemoryStream();
            bitmap.Save(ms, PngBitmapEncoderOptions.Default);
            ms.Position = 0;

            using var resized = Bitmap.DecodeToWidth(ms, 64);
            using var pngStream = new MemoryStream();
            resized.Save(pngStream, PngBitmapEncoderOptions.Default);
            byte[] pngBytes = pngStream.ToArray();

            using var writer = new BinaryWriter(output);
            writer.Write((short)0);
            writer.Write((short)1);
            writer.Write((short)1);
            writer.Write((byte)64);
            writer.Write((byte)64);
            writer.Write((byte)0);
            writer.Write((byte)0);
            writer.Write((short)1);
            writer.Write((short)32);
            writer.Write(pngBytes.Length);
            writer.Write(22);
            writer.Write(pngBytes);
        }

        public static string SanitizeFileName(string name)
        {
            foreach (char c in Path.GetInvalidFileNameChars())
                name = name.Replace(c, '_');

            var sb = new System.Text.StringBuilder(name.Length);
            foreach (char c in name)
            {
                if (c >= ' ' && c <= '~')
                    sb.Append(c);
            }

            string result = sb.ToString().Trim().TrimEnd('.');
            return string.IsNullOrWhiteSpace(result) ? "Shortcut" : result;
        }

        private static string ComputeHash(byte[] data)
        {
            return FastHash.FromBytes(data);
        }
    }
}