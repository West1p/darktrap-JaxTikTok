﻿// SPDX-FileCopyrightText: 2026 Froststrap
//
// SPDX-License-Identifier: MPL-2.0

namespace Froststrap.Enums
{
    internal enum StudioRenderer
    {
        DXVK,
        D3D11,
        D3D11FL10,
        Vulkan,
        OpenGL
    }
}