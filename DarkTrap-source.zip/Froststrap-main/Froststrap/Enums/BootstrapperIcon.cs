﻿// SPDX-FileCopyrightText: 2026 Froststrap
//
// SPDX-License-Identifier: MPL-2.0

namespace Froststrap.Enums
{
    internal enum BootstrapperIcon
    {
        [EnumName(StaticName = "Froststrap")]
        IconFroststrap,
        [EnumName(StaticName = "2008")]
        Icon2008,
        [EnumName(StaticName = "2011")]
        Icon2011,
        [EnumName(FromTranslation = "Enums.BootstrapperIcon.IconEarly2015")]
        IconEarly2015,
        [EnumName(FromTranslation = "Enums.BootstrapperIcon.IconLate2015")]
        IconLate2015,
        [EnumName(StaticName = "2017")]
        Icon2017,
        [EnumName(StaticName = "2019")]
        Icon2019,
        [EnumName(StaticName = "2022")]
        Icon2022,
        [EnumName(StaticName = "2025")]
        Icon2025,
        [EnumName(FromTranslation = "Common.Custom")]
        IconCustom,
        [EnumName(FromTranslation = "Enums.BootstrapperIcon.IconFroststrapClassic")]
        IconFroststrapClassic
    }
}