{
  lib,
  fontconfig,
  appimageTools,
  fetchurl,
  makeDesktopItem,
  version,
  sha256,
}:
let
  src = fetchurl {
    url = "https://github.com/Froststrap/Froststrap/releases/download/v${version}/Froststrap-linux-x64.AppImage";
    inherit sha256;
  };

  appimageContents = appimageTools.extractType2 {
    inherit version src;
    pname = "froststrap";
  };

  desktopItem = makeDesktopItem {
    name = "froststrap";
    desktopName = "Froststrap";
    comment = "A cross-platform Roblox bootstrapper, focused on performance and customization.";
    exec = "froststrap %u";
    icon = "froststrap";
    categories = [ "Game" ];
    mimeTypes = [
      "x-scheme-handler/roblox"
      "x-scheme-handler/roblox-player"
      "x-scheme-handler/roblox-studio"
      "x-scheme-handler/roblox-studio-auth"
    ];
  };
in
appimageTools.wrapType2 {
  pname = "froststrap";
  inherit version src;

  extraPkgs =
    pkgs: with pkgs; [
      icu
      fontconfig
      dbus
    ];

  # list values must end with ";". makeDesktopItem omits it.
  extraInstallCommands = ''
    install -Dm644 ${desktopItem}/share/applications/froststrap.desktop \
        $out/share/applications/froststrap.desktop

    sed -i -E '/^(Categories|MimeType)=/ s/([^;])$/\1;/' \
        $out/share/applications/froststrap.desktop

    install -Dm644 ${appimageContents}/usr/share/icons/hicolor/scalable/apps/Froststrap.png \
        $out/share/icons/hicolor/512x512/apps/froststrap.png
  '';

  meta = {
    description = "A cross-platform Roblox bootstrapper, focused on performance and customization.";
    homepage = "https://froststrap.xyz/";
    license = lib.licenses.mpl20;
    platforms = [ "x86_64-linux" ];
  };
}
